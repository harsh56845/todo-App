import 'package:flutter/material.dart';

import '../model/task_model.dart';

class TaskController extends ChangeNotifier {
  final List<TaskModel> _tasks = [
    TaskModel(title: "WorkingOut"),
    TaskModel(title: "Playing Chess"),
  ];

  List<TaskModel> get tasks => _tasks;

  void addTask(String title) {
    _tasks.add(TaskModel(title: title));
    notifyListeners();
  }

  void deleteTask(int index) {
    _tasks.removeAt(index);
    notifyListeners();
  }

  void editTask(int index, String newTitle) {
    _tasks[index].title = newTitle;
    _tasks[index].isChecked = false;
    notifyListeners();
  }

  void toggleCheck(int index, bool value) {
    _tasks[index].isChecked = value;
    notifyListeners();
  }

  int get taskCount => _tasks.length;
}
