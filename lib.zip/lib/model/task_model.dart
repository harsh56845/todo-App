class TaskModel {
  String title;
  bool isChecked;

  TaskModel({required this.title, this.isChecked = false});
}
