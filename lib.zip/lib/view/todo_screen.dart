import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:todo_flutter_app_2/controller/task_controller.dart';
import 'package:todo_flutter_app_2/model/task_model.dart';

class TodoPage extends StatefulWidget {
  final String userEmail;

  const TodoPage({super.key, required this.userEmail});

  @override
  State<TodoPage> createState() => _TodoPageState();
}

class _TodoPageState extends State<TodoPage> {
  // final TaskController _controller = TaskController();
  late TaskController controller;
  final TextEditingController _tasktitle = TextEditingController();
  final TextEditingController _editTask = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    controller = Provider.of<TaskController>(context);
  }

  void addUserData(String email) async {
    await FirebaseFirestore.instance.collection('todos').add({
      'title': _tasktitle.text,
      'isChecked': false,
      'createdAt': FieldValue.serverTimestamp(),
      'email': email.trim().toLowerCase(),
    });
  }

  _addTask() {
    if (_tasktitle.text.isNotEmpty) {
      setState(() {
        addUserData(widget.userEmail);
      });

      // controller.addTask(_tasktitle.text);
      // _taskList.add({"title": _tasktitle.text, "isChecked": false});
      _tasktitle.clear();

      _snackBarMessage(' Task Added Sucessfully', Colors.green);
    } else {
      _snackBarMessage('⚠️ TextFeild Cannot Empty', Colors.redAccent);
    }
  }

  _delTask(docId) async {
    // controller.deleteTask(i);
    // void deleteTodo(String docId) async {
    await FirebaseFirestore.instance.collection('todos').doc(docId).delete();
    // }
    _snackBarMessage(' Task Deleted Sucessfully', Colors.blue);
  }

  _editTaskFun(int i) {
    _editTask.text = controller.tasks[i].title;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Edit Task"),
        content: TextField(
          controller: _editTask,
          decoration: InputDecoration(
            hintText: "Enter new task name",
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // cancel
            },
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              controller.editTask(i, _editTask.text);
              // _taskList[i] = {"title": _editTask.text, "isChecked": false};

              _snackBarMessage('task Edit SucessFully', Colors.green);
              Navigator.pop(context); // close popup
            },
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  _snackBarMessage(String str, Color clr) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(str),
        backgroundColor: clr,
        // duration: Duration(seconds: 1),
        duration: Duration(milliseconds: 800),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<TaskModel> taskList = controller.tasks;
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(
            "📝 ToDo App",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.0,
            ),
          ),
          centerTitle: true,
          elevation: 4,
          backgroundColor: const Color(0xFF673AB7), // deep purple
          actions: [
            IconButton(
              icon: Icon(Icons.info_outline, color: Colors.white),
              tooltip: "About App",
              onPressed: () {
                showAboutDialog(
                  context: context,
                  applicationName: "ToDo App",
                  applicationVersion: "v1.0",
                  children: [Text("Made with ❤️ by Harsh")],
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.exit_to_app, color: Colors.white),
              tooltip: "Logout",
              onPressed: () {
                // Navigate to LoginScreen
                Navigator.pushReplacementNamed(context, '/login');
              },
            ),
          ],
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 50),
              Column(
                children: [
                  Text(
                    "👋 Welcome, Harsh!",
                    style: GoogleFonts.poppins(
                      fontSize: 22,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF673AB7),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "🗓️ Let's plan your day\n🚀 Stay focused & get things done!",
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[700],
                      height: 1.4,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
              // Text(
              //   "Time to conquer your goals, Harsh! Whats on your list today?",
              //   style: GoogleFonts.poppins(
              //     fontSize: 22,
              //     fontWeight: FontWeight.w600,
              //     color: const Color(0xFF673AB7),
              //   ),
              // ),
              SizedBox(height: 20),

              Text(
                "Total tasks: ${controller.taskCount}",
                style: TextStyle(color: Colors.grey),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 90),
                  SizedBox(
                    width: 300,
                    child: TextField(controller: _tasktitle),
                  ),
                  SizedBox(
                    width: 60,
                    child: TextButton.icon(
                      onPressed: () {
                        _addTask();
                      },
                      label: Icon(Icons.add, size: 32, color: Colors.green),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Expanded(
                child: SizedBox(
                  height: 300,
                  width: 500,
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('todos')
                        .where(
                          'email',
                          isEqualTo: widget.userEmail.trim().toLowerCase(),
                        )
                        .orderBy('createdAt', descending: true)
                        .snapshots(),

                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      FirebaseFirestore.instance.collection('todos').get().then((
                        snapshot,
                      ) {
                        for (var doc in snapshot.docs) {
                          final data = doc.data();
                          final storedEmail = data['email'];
                          print("Doc ID: ${doc.id}");
                          print(
                            "Stored: '$storedEmail' | Widget: '${widget.userEmail}'",
                          );
                          print("Equal? → ${storedEmail == widget.userEmail}");
                        }
                      });
                      // FirebaseFirestore.instance.collection('todos').get().then((
                      //   snapshot,
                      // ) {
                      //   for (var doc in snapshot.docs) {
                      //     print(
                      //       "ID: ${doc.id} → ${doc.data()['email'].toString()}",
                      //     );
                      //     print(
                      //       "${widget.userEmail} == ${doc.data()['email'].toString()}",
                      //     );
                      //     print(
                      //       "is True or false ? ==>. ${widget.userEmail == doc.data()['email'].toString()}",
                      //     );
                      //   }
                      // });

                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(child: Text("No tasks found"));
                      }

                      final tasks = snapshot.data!.docs;

                      return ListView.builder(
                        itemCount: tasks.length,
                        itemBuilder: (context, i) {
                          final task = tasks[i].data() as Map<String, dynamic>;
                          final docId = tasks[i].id;

                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                              child: ListTile(
                                title: Text(
                                  task['title'],
                                  style: GoogleFonts.poppins(
                                    textStyle: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      decoration: task['isChecked']
                                          ? TextDecoration.lineThrough
                                          : TextDecoration.none,
                                    ),
                                  ),
                                ),
                                trailing: SizedBox(
                                  width: 120,
                                  child: Row(
                                    children: [
                                      IconButton(
                                        onPressed: () => {},
                                        // _editTaskFun(context, docId, task),
                                        icon: const Icon(
                                          Icons.edit,
                                          color: Colors.blue,
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: () => {},
                                        // _deleteTask(docId),
                                        icon: const Icon(
                                          Icons.delete,
                                          color: Colors.red,
                                        ),
                                      ),
                                      Checkbox(
                                        value: task['isChecked'],
                                        onChanged: (val) => {},
                                        // _toggleCheck(docId, val ?? false),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                  //  ListView.builder(
                  //   itemCount: taskList.length,
                  //   itemBuilder: (context, i) {
                  //     return Padding(
                  //       padding: const EdgeInsets.all(8.0),
                  //       child: Card(
                  //         child: ListTile(
                  //           title: Text(
                  //             taskList[i].title,
                  //             style: GoogleFonts.poppins(
                  //               textStyle: TextStyle(
                  //                 fontWeight: FontWeight.bold,
                  //                 decoration: taskList[i].isChecked
                  //                     ? TextDecoration.lineThrough
                  //                     : TextDecoration.none,
                  //               ),
                  //             ),
                  //           ),
                  //           trailing: SizedBox(
                  //             width: 120,
                  //             child: Row(
                  //               children: [
                  //                 IconButton(
                  //                   onPressed: () => _editTaskFun(i),
                  //                   icon: Icon(Icons.edit, color: Colors.blue),
                  //                 ),
                  //                 IconButton(
                  //                   onPressed: () => _delTask(i),
                  //                   icon: Icon(Icons.delete, color: Colors.red),
                  //                 ),
                  //                 Checkbox(
                  //                   value: taskList[i].isChecked,
                  //                   onChanged: (val) {
                  //                     // taskList[i].isChecked = val!;
                  //                     controller.toggleCheck(i, val!);
                  //                   },
                  //                 ),
                  //               ],
                  //             ),
                  //           ),
                  //         ),
                  //       ),
                  //     );
                  //   },
                  // ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 12.0),
                child: Text(
                  "Made by Harsh ❤️",
                  style: TextStyle(color: Colors.grey, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
