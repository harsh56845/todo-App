import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todo_flutter_app_2/controller/auth_service.dart';
import 'package:todo_flutter_app_2/view/todo_screen.dart';
import 'package:todo_flutter_app_2/widgets/footer.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback onToggle;

  LoginScreen({super.key, required this.onToggle});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _auth = AuthService();

  final TextEditingController _email = TextEditingController();

  final TextEditingController _password = TextEditingController();
  String userEmail = "";

  void _login(context) async {
    try {
      // if (isLogin) {
      await _auth.signIn(_email.text, _password.text);
      userEmail = _auth.currentUser!.email!;
      // } else {
      // await _auth.signUp(_email.text, _password.text);
      // }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Success!")));
      // Navigator.pushNamed(context, '/home');
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => TodoPage(userEmail: userEmail)),
      );
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: ${e.toString()}")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey.shade50,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Icon(Icons.lock_open, size: 100, color: Colors.deepPurple),
              const SizedBox(height: 20),
              Text(
                "Welcome Back",
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              _buildTextField("Email", Icons.email, txtcont: _email),
              const SizedBox(height: 12),
              _buildTextField(
                "Password",
                Icons.lock,
                obscureText: true,
                txtcont: _password,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: Icon(Icons.login),
                label: Text("Login"),
                onPressed: () {
                  _login(context);
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: widget.onToggle,
                child: Text("Don't have an account? Sign up"),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const AppFooter(),
    );
  }

  Widget _buildTextField(
    String hint,
    IconData icon, {
    bool obscureText = false,
    TextEditingController? txtcont,
  }) {
    return TextField(
      controller: txtcont,
      obscureText: obscureText,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }
}
