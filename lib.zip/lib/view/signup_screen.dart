// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';

// class SignUpScreen extends StatelessWidget {
//   final VoidCallback onToggle;

//   SignUpScreen({required this.onToggle});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blueGrey.shade50,
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24),
//           child: Column(
//             children: [
//               Icon(Icons.app_registration, size: 100, color: Colors.deepPurple),
//               const SizedBox(height: 20),
//               Text(
//                 "Create Account",
//                 style: GoogleFonts.poppins(
//                   fontSize: 28,
//                   fontWeight: FontWeight.w600,
//                 ),
//               ),
//               const SizedBox(height: 20),
//               _buildTextField("Email", Icons.email),
//               const SizedBox(height: 12),
//               _buildTextField("Password", Icons.lock, obscureText: true),
//               const SizedBox(height: 12),
//               _buildTextField(
//                 "Confirm Password",
//                 Icons.lock_outline,
//                 obscureText: true,
//               ),
//               const SizedBox(height: 24),
//               ElevatedButton.icon(
//                 icon: Icon(Icons.person_add, color: Colors.deepPurple),
//                 label: Text(
//                   "Sign Up",
//                   style: TextStyle(color: Colors.deepPurple),
//                 ),
//                 onPressed: () {}, // Add your signup logic
//                 style: ElevatedButton.styleFrom(
//                   minimumSize: Size(double.infinity, 50),
//                 ),
//               ),
//               const SizedBox(height: 10),
//               TextButton(
//                 onPressed: onToggle,
//                 child: Text("Already have an account? Log in"),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildTextField(
//     String hint,
//     IconData icon, {
//     bool obscureText = false,
//   }) {
//     return TextField(
//       obscureText: obscureText,
//       decoration: InputDecoration(
//         prefixIcon: Icon(icon),
//         hintText: hint,
//         border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
//         filled: true,
//         fillColor: Colors.white,
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:todo_flutter_app_2/controller/auth_service.dart';
import 'package:todo_flutter_app_2/widgets/footer.dart';

class SignUpScreen extends StatefulWidget {
  final VoidCallback onToggle;

  SignUpScreen({super.key, required this.onToggle});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final AuthService _auth = AuthService();

  final TextEditingController _email = TextEditingController();

  final TextEditingController _password = TextEditingController();

  void _submit(context) async {
    try {
      // if (isLogin) {
      //   await _auth.signIn(_email.text, _password.text);
      // } else {
      await _auth.signUp(_email.text, _password.text);
      // }
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Success!")));
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: ${e.toString()}")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey.shade50,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Icon(Icons.app_registration, size: 100, color: Colors.deepPurple),
              const SizedBox(height: 20),
              Text(
                "Create Account",
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 20),
              _buildTextField("Username", Icons.person),
              const SizedBox(height: 12),
              _buildTextField("Email", Icons.email, textCont: _email),
              const SizedBox(height: 12),
              _buildTextField(
                "Password",
                Icons.lock,
                obscureText: true,
                textCont: _password,
              ),
              const SizedBox(height: 12),
              _buildTextField(
                "Confirm Password",
                Icons.lock_outline,
                obscureText: true,
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                icon: Icon(Icons.person_add, color: Colors.deepPurple),
                label: Text(
                  "Sign Up",
                  style: TextStyle(color: Colors.deepPurple),
                ),
                onPressed: () {
                  setState(() {
                    _submit(context);
                  });
                }, // Add your signup logic
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: widget.onToggle,
                child: Text("Already have an account? Log in"),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const AppFooter(),
    );
  }

  Widget _buildTextField(
    String hint,
    IconData icon, {
    bool obscureText = false,
    TextEditingController? textCont,
  }) {
    return TextField(
      controller: textCont,
      obscureText: obscureText,
      decoration: InputDecoration(
        prefixIcon: Icon(icon),
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }
}
